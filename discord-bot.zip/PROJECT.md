# Project: Minecraft-Discord Backend Bot Refactoring

## Architecture
The bot bridges Minecraft and Discord. It consists of:
1. Discord Bot Client (`src/bot/client.js`): Interacts with Discord API, registers slash commands.
2. WebSocket Server (`src/websocket/server.js`): Listens for connection requests from Minecraft server instances, receives events and status packets.
3. Database Layer (`src/database/index.js`): Stores Discord-to-Minecraft player bindings, temp verification codes, support ticket channels, and settings.
4. Services (`src/services/`): Webhook relay, Support Tickets, Status display.

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|---|---|---|---|
| 1 | Database & Repository Pattern Refactoring | Rewrite `src/database/index.js` to async. Create UserRepository, TicketRepository, SettingRepository, PlayerStatsRepository. | None | COMPLETED |
| 2 | WebSocket Reliability, Security & Connection Pool | Ping/Pong heartbeat, Map-based server sessions, connection rate limiting, zod auth packet schema. | M1 | COMPLETED |
| 3 | Interaction Handling Refactor | Extract command/button/modal handling from `src/index.js` to separate files. | None | COMPLETED |
| 4 | Middleware-Oriented Command System Refactoring | Setup command router, middleware pipeline (Auth/Role white-list, Logger, Rate limits/Cooldown, Exception catching). | M3 | COMPLETED |
| 5 | Discord API Buffering Queue System | Centralize Discord outgoing messages via `p-queue` to honor rate limits and retry transient errors. | None | COMPLETED |
| 6 | Structured Logging, Error Safety & Bug Fixes | Replace console.log with winston, define AppError, process safety (unhandledRejection/uncaughtException), fix db import in webhookService.js. | M1, M5 | COMPLETED |
| 7 | Verification & Final Acceptance | Run all tests (97 tests), perform coverage audit and generate README.md. | M1, M2, M3, M4, M5, M6 | COMPLETED |

*Note: Milestones 1, 2, and 3 are batched together and are being executed simultaneously in a single phase under Conv ID: 10563f74-04b1-4502-b169-397c12cb549b.*

*Note: Milestones 4, 5, and 6 are batched together and are being executed simultaneously in a single phase under Conv ID: 1c10ca8d-0d99-422b-b3ed-005355009a43.*

## Interface Contracts
### Database Async Interface
- `async init(dbPath): Promise<void>`
- `async close(): Promise<void>`
- `async addBinding(discordId, mcUuid, mcUsername): Promise<void>`
- `async getBindingByDiscordId(discordId): Promise<object|null>`
- `async getBindingByMcUuid(mcUuid): Promise<object|null>`
- `async getBindingByMcUsername(mcUsername): Promise<object|null>`
- `async removeBindingByDiscordId(discordId): Promise<void>`
- `async createTempCode(mcUuid, mcUsername, code): Promise<void>`
- `async getTempCode(code): Promise<object|null>`
- `async deleteTempCode(code): Promise<void>`
- `async clearExpiredTempCodes(): Promise<void>`
- `async createTicket(ticketId, channelId, creatorId): Promise<void>`
- `async closeTicket(channelId): Promise<void>`
- `async incrementDeath(mcUuid, mcUsername): Promise<void>`
- `async getDeathLeaderboard(limit): Promise<array>`
- `async getUserKeys(discordId): Promise<object|null>`
- `async updateKeys(discordId, newCount): Promise<void>`
- `async setCheckin(discordId, dateStr, keysToAdd): Promise<void>`
- `async addKeysByMcUsername(mcUsername, keysToAdd): Promise<void>`
- `async addKeysByDiscordId(discordId, keysToAdd): Promise<void>`
- `async bindUser(discordId, mcUuid, mcUsername, code): Promise<void>` (Async Transaction)

### WebSocket Session Pool Interface
- `setConnection(serverId, ws): void`
- `getConnection(serverId): ws`
- `removeConnection(serverId): void`
- `hasConnection(serverId): boolean`

## Code Layout
- `src/index.js` - Minimal app entrypoint
- `src/config.js` - Dotenv & configuration loading
- `src/bot/` - Discord client and handler files
- `src/database/` - SQLite connection, schema, repositories
- `src/services/` - Business services (Webhooks, Tickets, Status)
- `src/websocket/` - WebSocket Server, sessions, and packets handler
