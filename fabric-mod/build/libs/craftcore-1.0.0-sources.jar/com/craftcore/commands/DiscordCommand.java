package com.craftcore.commands;

import com.craftcore.CraftCoreMod;
import com.craftcore.config.ConfigManager;
import com.craftcore.websocket.Packet;
import com.craftcore.websocket.CraftCoreWSClient;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class DiscordCommand {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("discord")
                    .executes(context -> {
                        context.getSource().method_45068(class_2561.method_43470("Discord Invite: " + ConfigManager.getConfig().discordInvite));
                        return 1;
                    })
                    .then(class_2170.method_9247("link")
                            .executes(DiscordCommand::initiateBind))
                    .then(class_2170.method_9247("bind")
                            .executes(DiscordCommand::initiateBind))
            );

            dispatcher.register(class_2170.method_9247("playerinfo")
                    .requires(source -> source.method_75037().hasPermission(net.minecraft.class_12099.field_63212))
                    .then(class_2170.method_9244("username", StringArgumentType.word())
                            .executes(DiscordCommand::playerInfo))
            );

            dispatcher.register(class_2170.method_9247("ccplayerinfo")
                    .requires(source -> source.method_75037().hasPermission(net.minecraft.class_12099.field_63212))
                    .then(class_2170.method_9244("username", StringArgumentType.word())
                            .executes(DiscordCommand::playerInfo))
            );
        });
    }

    private static int initiateBind(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_45068(class_2561.method_43470("This command can only be executed by players."));
            return 0;
        }

        CraftCoreWSClient client = CraftCoreMod.getWSClient();
        if (client == null || !client.isAuthenticated()) {
            source.method_45068(class_2561.method_43470("[CraftCore] WebSocket connection is offline. Please try again later."));
            return 0;
        }

        String username = player.method_5477().getString();
        String uuid = player.method_5845();
        client.send(new Packet("bind_code_request", new Packet.BindCodeRequestPayload(username, uuid)));
        source.method_45068(class_2561.method_43470("[CraftCore] Requesting bind code..."));
        return 1;
    }

    private static int playerInfo(CommandContext<class_2168> context) {
        String username = StringArgumentType.getString(context, "username");
        class_2168 source = context.getSource();
        class_3222 serverPlayer = source.method_9211().method_3760().method_14566(username);

        if (serverPlayer != null) {
            double x = serverPlayer.method_23317();
            double y = serverPlayer.method_23318();
            double z = serverPlayer.method_23321();
            String dim = "Unknown";
            String dimKey = serverPlayer.method_51469().method_27983().method_29177().method_12832().toLowerCase();
            if (dimKey.contains("overworld")) {
                dim = "主世界";
            } else if (dimKey.contains("nether")) {
                dim = "地獄";
            } else if (dimKey.contains("end")) {
                dim = "終界";
            } else {
                dim = dimKey;
            }
            source.method_45068(class_2561.method_43470(String.format("Online: true, Coords: X: %.2f Y: %.2f Z: %.2f, Dimension: %s", x, y, z, dim)));
        } else {
            String lastOnline = ConfigManager.getPlayerLastOnline(username);
            if (lastOnline == null) {
                lastOnline = "Unknown";
            }
            source.method_45068(class_2561.method_43470(String.format("Online: false, LastOnline: %s", lastOnline)));
        }
        return 1;
    }
}
