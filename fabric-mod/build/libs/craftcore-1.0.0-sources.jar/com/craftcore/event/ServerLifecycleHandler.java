package com.craftcore.event;

import com.craftcore.CraftCoreMod;
import com.craftcore.config.ConfigManager;
import com.craftcore.websocket.Packet;
import com.craftcore.websocket.CraftCoreWSClient;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ServerLifecycleHandler {
    private static ScheduledExecutorService telemetryScheduler;

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            System.out.println("[CraftCore] Server started. Initializing WebSocket connection.");
            ConfigManager.loadConfig();
            ConfigManager.loadPlayers();
            CraftCoreMod.startWSClient(server);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            System.out.println("[CraftCore] Server stopping. Cleaning up resources.");
            stopTelemetryLoop();
            CraftCoreMod.stopWSClient();
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            if (player != null) {
                String username = player.method_5477().getString();
                String uuid = player.method_5845();

                CraftCoreWSClient client = CraftCoreMod.getWSClient();
                if (client != null && client.isAuthenticated()) {
                    client.send(new Packet("event", new Packet.EventPayload(
                            "join", username, uuid, username + " joined the game"
                    )));
                }
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            class_3222 player = handler.method_32311();
            if (player != null) {
                String username = player.method_5477().getString();
                String uuid = player.method_5845();
                ConfigManager.updatePlayerLastOnline(username);

                CraftCoreWSClient client = CraftCoreMod.getWSClient();
                if (client != null && client.isAuthenticated()) {
                    client.send(new Packet("event", new Packet.EventPayload(
                            "leave", username, uuid, username + " left the game"
                    )));
                }
            }
        });

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String username = sender.method_5477().getString();
            String uuid = sender.method_5845();
            String content = message.method_46291().getString();

            CraftCoreWSClient client = CraftCoreMod.getWSClient();
            if (client != null && client.isAuthenticated()) {
                client.send(new Packet("chat", new Packet.ChatPayload(username, uuid, content)));
            }
        });
    }

    public static synchronized void startTelemetryLoop(MinecraftServer server, CraftCoreWSClient client) {
        if (telemetryScheduler == null || telemetryScheduler.isShutdown()) {
            telemetryScheduler = Executors.newSingleThreadScheduledExecutor();
            telemetryScheduler.scheduleAtFixedRate(() -> {
                try {
                    if (client != null && client.isAuthenticated()) {
                        server.execute(() -> {
                            try {
                                double tps = Math.min(20.0, 1000.0 / server.method_54832());
                                int totalPing = 0;
                                List<class_3222> players = server.method_3760().method_14571();
                                List<String> playerNames = new ArrayList<>();
                                for (class_3222 p : players) {
                                    totalPing += p.field_13987.method_52405();
                                    playerNames.add(p.method_5477().getString());
                                }
                                int avgPing = players.isEmpty() ? 0 : totalPing / players.size();
                                int currentPlayers = players.size();
                                int maxPlayers = server.method_3760().method_14592();

                                Packet.StatusPayload payload = new Packet.StatusPayload(
                                        true, tps, avgPing, currentPlayers, maxPlayers, playerNames
                                    );
                                Packet packet = new Packet("status", payload);
                                CompletableFuture.runAsync(() -> {
                                    try {
                                        client.send(packet);
                                    } catch (Exception e) {
                                        System.err.println("[CraftCore] Error sending telemetry packet: " + e.getMessage());
                                    }
                                });
                            } catch (Exception e) {
                                System.err.println("[CraftCore] Error gathering telemetry statistics: " + e.getMessage());
                            }
                        });
                    }
                } catch (Exception e) {
                    System.err.println("[CraftCore] Error in telemetry loop: " + e.getMessage());
                }
            }, 10, 10, TimeUnit.SECONDS);
            System.out.println("[CraftCore] Started 10s status telemetry loop.");
        }
    }

    public static synchronized void stopTelemetryLoop() {
        if (telemetryScheduler != null) {
            telemetryScheduler.shutdown();
            try {
                if (!telemetryScheduler.awaitTermination(2, TimeUnit.SECONDS)) {
                    telemetryScheduler.shutdownNow();
                }
            } catch (InterruptedException e) {
                telemetryScheduler.shutdownNow();
            }
            telemetryScheduler = null;
            System.out.println("[CraftCore] Stopped status telemetry loop.");
        }
    }
}
