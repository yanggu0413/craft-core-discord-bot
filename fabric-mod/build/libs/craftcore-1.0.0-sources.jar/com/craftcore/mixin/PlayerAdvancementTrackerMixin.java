package com.craftcore.mixin;

import com.craftcore.CraftCoreMod;
import com.craftcore.websocket.Packet;
import net.minecraft.class_167;
import net.minecraft.class_2985;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import com.craftcore.websocket.CraftCoreWSClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2985.class)
public class PlayerAdvancementTrackerMixin {

    @Shadow
    private class_3222 owner;

    @Inject(method = "grantCriterion", at = @At("RETURN"))
    private void onGrantCriterion(class_8779 advancement, String criterionName, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) {
            class_2985 tracker = (class_2985) (Object) this;
            class_167 progress = tracker.method_12882(advancement);
            if (progress.method_740()) {
                advancement.comp_1920().comp_1913().ifPresent(display -> {
                    if (display.method_808()) {
                        String username = owner.method_5477().getString();
                        String uuid = owner.method_5845();
                        String title = display.method_811().getString();
                        String description = display.method_817().getString();
                        String itemId = net.minecraft.class_7923.field_41178.method_10221(display.method_821().method_7909()).toString();
                        String details = title + "|" + description + "|" + itemId;

                        CraftCoreWSClient client = CraftCoreMod.getWSClient();
                        if (client != null && client.isAuthenticated()) {
                            client.send(new Packet("event", new Packet.EventPayload(
                                    "advancement", username, uuid, details
                             )));
                        }
                    }
                });
            }
        }
    }
}
