package com.craftcore.mixin;

import com.craftcore.CraftCoreMod;
import com.craftcore.websocket.Packet;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import com.craftcore.websocket.CraftCoreWSClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public class ServerPlayerEntityMixin {
    @Inject(method = "onDeath", at = @At("TAIL"))
    private void onPlayerDeath(class_1282 damageSource, CallbackInfo ci) {
        class_3222 player = (class_3222) (Object) this;
        String username = player.method_5477().getString();
        String uuid = player.method_5845();
        String deathMessage = player.method_6066().method_5548().getString();

        CraftCoreWSClient client = CraftCoreMod.getWSClient();
        if (client != null && client.isAuthenticated()) {
            client.send(new Packet("event", new Packet.EventPayload(
                    "death", username, uuid, deathMessage
            )));
        }
    }
}
