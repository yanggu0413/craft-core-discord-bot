package com.craftcore.websocket;

import net.minecraft.class_2165;
import net.minecraft.class_2561;

public class WSCommandOutput implements class_2165 {
    private final StringBuilder output = new StringBuilder();

    @Override
    public void method_43496(class_2561 message) {
        output.append(message.getString()).append("\n");
    }

    @Override
    public boolean method_9200() {
        return true;
    }

    @Override
    public boolean method_9202() {
        return true;
    }

    @Override
    public boolean method_9201() {
        return false;
    }

    public String getCapturedOutput() {
        return output.toString().trim();
    }
}
